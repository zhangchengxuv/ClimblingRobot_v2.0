#include "rclcpp/rclcpp.hpp"
#include "serial/serial.h"
#include "std_msgs/msg/float64.hpp"
#include <iostream>
#include <cmath>

serial::Serial ser;
using namespace std::chrono_literals;
// 3.自定义节点类；
class Data_Collect : public rclcpp::Node

{
public:
    Data_Collect() : Node("Data_Collect_node_cpp")
    {
        // 4.创建定时器，周期为10ms
        data_collect_timer_ = this->create_wall_timer(100ms, std::bind(&Data_Collect::data_collect_callback, this));
    }

private:
    // 定义定时器
    rclcpp::TimerBase::SharedPtr data_collect_timer_;
    // 定义回调函数
    void data_collect_callback()
    {
        // 定义一个Buffer接受订阅消息
        uint8_t Readdate[15] = {0};
        // 从串口读取数据
        ser.read(Readdate, 15);
        // 打印接收到的数据
        std::cout << "Received data: ";
        for (size_t i = 15; i < 15; i++)
        {
            std::cout << Readdate[i] << std::endl;
        }
    }
};

int main(int argc, char const *argv[])
{
    rclcpp::init(argc, argv);
    ser.setPort("/dev/ttyS0");
    ser.setBaudrate(19200);
    serial::Timeout to = serial::Timeout::simpleTimeout(1000);
    ser.setTimeout(to);
    try
    {
        ser.open();
    }
    catch (serial::IOException &e)
    {
        std::cout << "unable to open" << std::endl;
        return -1;
    }
    if (ser.isOpen())
    {
        std::cout << "-----open------" << std::endl;
    }
    else
    {
        return -1;
    }
    // 4.调用spain函数，并传入节点对象指针；
    rclcpp::spin(std::make_shared<Data_Collect>());
    // 5.资源释放
    rclcpp::shutdown();
    ser.close();
    return 0;
}